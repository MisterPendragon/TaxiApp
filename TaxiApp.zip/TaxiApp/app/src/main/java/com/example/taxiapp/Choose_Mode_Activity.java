package com.example.taxiapp;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.icu.number.Scale;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import java.util.concurrent.TimeUnit;

public class Choose_Mode_Activity extends AppCompatActivity {

    ImageView passengerImageView;
    ImageView carImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_mode);

        passengerImageView=findViewById(R.id.passengerImageView);
        carImageView=findViewById(R.id.carImageView);

    }

    public void goToPassenger(View view) throws InterruptedException {
       Animation animation=AnimationUtils.loadAnimation(this,R.anim.click_animation);
       passengerImageView.startAnimation(animation);

        startActivity(new Intent(Choose_Mode_Activity.this,PassengerSignIn.class));
    }

    public void goToDriver(View view) {
        Animation animation=AnimationUtils.loadAnimation(this,R.anim.click_animation);
        carImageView.startAnimation(animation);


        startActivity(new Intent(Choose_Mode_Activity.this,DriverSignIn.class));
    }
}